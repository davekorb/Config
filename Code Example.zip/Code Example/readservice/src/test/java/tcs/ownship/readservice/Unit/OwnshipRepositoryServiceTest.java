package tcs.ownship.readservice.Unit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import tcs.ownship.readservice.data.Ownship;
import tcs.ownship.readservice.dbase.OwnshipEntity;
import tcs.ownship.readservice.dbase.OwnshipEntityMapper;
import tcs.ownship.readservice.dbase.OwnshipRepository;
import tcs.ownship.readservice.dbase.OwnshipRepositoryService;

import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class OwnshipRepositoryServiceTest
{
  RandomGenerator randomGenerator = new RandomGenerator(new Random());

  @Mock
  OwnshipRepository ownshipRepo;

  @InjectMocks
  OwnshipRepositoryService ownshipRepoService;

  @Captor
  ArgumentCaptor<List<OwnshipEntity>> ownshipEntityCaptor;


  @Test
  @DisplayName("Test findAll method with 0 entries")
  void TestFindAllWithNoEntries()
  {
    verifyFindAll(0);
  }

  @Test
  @DisplayName("Test findAll method with multiple entries")
  void TestFindAllWithMultipleEntries()
  {
    verifyFindAll(randomGenerator.generateInteger(1, 100));
  }

  /**
  /**
   * Utility function to test multiple return amounts from the findAll
   * @param count - the number of records to test for
   */
  void verifyFindAll(int count)
  {
    List<Ownship> ownshipList = randomGenerator.generateOwnshipList(count);
    List<OwnshipEntity> entities = OwnshipEntityMapper.INSTANCE.toEntities(ownshipList);

    Mockito.when(ownshipRepo.findAll()).thenReturn(entities);

    List<Ownship> returnedOwnshipList = ownshipRepoService.findAll();

    // Verify that the Repository's "findAll" was called correctly.
    verify(ownshipRepo, times(1)).findAll();

    // Verify that the correct number of records was translated and returned
    assertEquals(ownshipList.size(), returnedOwnshipList.size(),
      "Did not get correct number of ownship records");
    assertTrue(ownshipList.containsAll(returnedOwnshipList),
      "Did not get correct ownship records");
  }
}
