package tcs.ownship.readservice.Unit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import tcs.ownship.readservice.data.Ownship;
import tcs.ownship.readservice.dbase.OwnshipEntity;
import tcs.ownship.readservice.dbase.OwnshipEntityMapper;
import tcs.ownship.readservice.dbase.OwnshipRepositoryService;
import tcs.ownship.readservice.rest.GetResponse;
import tcs.ownship.readservice.rest.OwnshipController;

import java.util.List;
import java.util.Objects;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

/**
 * Tests the OwnshipController
 */
@ExtendWith(MockitoExtension.class)
public class OwnshipControllerTest
{
  RandomGenerator randomGenerator = new RandomGenerator(new Random());

  @Mock
  OwnshipRepositoryService ownshipRepoService;

  @InjectMocks
  OwnshipController ownshipController;

  @Captor
  ArgumentCaptor<List<Ownship>> ownshipCaptor1;

  @Captor
  ArgumentCaptor<List<Ownship>> ownshipCaptor2;


  @Test
  @DisplayName("Test GetAll method with 0 entries")
  void TestGetAllWithNoEntries()
  {
    verifyGet(0);
  }

  @Test
  @DisplayName("Test GetAll method with 1 entries")
  void TestGetAllWithOneEntries()
  {
    verifyGet(1);
  }

  @Test
  @DisplayName("Test GetAll method with multiple entries")
  void TestGetAllWithMultipleEntries()
  {
    verifyGet(randomGenerator.generateInteger(2, 100));
  }

  /**
  /**
   * Utility function to test multiple return amounts from the getAll
   * @param count - the number of records to test for
   */
  void verifyGet(int count)
  {
    List<Ownship> ownshipList = randomGenerator.generateOwnshipList(count);

    Mockito.when(ownshipRepoService.findAll()).thenReturn(ownshipList);

    ResponseEntity<GetResponse> response =
      ownshipController.getAll();

    // Verify that the Repository's "findAll" was called correctly.
    verify(ownshipRepoService, times(1)).findAll();

    // Verify that the correct number of records was translated and returned
    assertEquals(count, Objects.requireNonNull(response.getBody()).getData().size(),
      "Did not get correct number of records");
    assertTrue(ownshipList.containsAll(response.getBody().getData()),
      "Did not get correct records");
  }

}
