package tcs.ownship.readservice.Unit;

import lombok.RequiredArgsConstructor;
import tcs.ownship.readservice.data.Ownship;

import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RequiredArgsConstructor
public class RandomGenerator
{
  private final Random generator;

  /**
   * Generates a random integer
   * @return The random int.
   */
  public int generateInteger(int min, int max)
  {
    return min + generator.nextInt(max - min);
  }

  /**
   * Generate a double value >= min and < max
   * @param min - the min value for the double
   * @param max - the max value for the double
   * @return The generated double
   */
  public double generateDouble(double min, double max)
  {
    return min + (generator.nextDouble() * (max - min));
  }


  /**
   * Generate an ownship filled with random values
   * @return The generated ownship
   */
  public Ownship generateOwnship()
  {
    return Ownship.builder()
      .id(UUID.randomUUID().toString())
      .latitude(generateDouble(-90, 90))
      .longitude(generateDouble(-180, 180))
      .mcsX(generateDouble(0, 10000))
      .mcsY(generateDouble(0, 10000))
      .bearing(generateDouble(0, 359))
      .course(generateDouble(0, 359))
      .speed(generateDouble(0, 10))
      .build();
  }

  /**
   * Generate a list of random ownship instances.
   * @param count - the number of ownship records to generate
   * @return a list of ownship classes of length "count"
   */
  public List<Ownship> generateOwnshipList(int count)
  {
    return Stream.iterate(0, index -> index + 1)
      .limit(count)
      .map(index -> generateOwnship())
      .collect(Collectors.toList());
  }
}
