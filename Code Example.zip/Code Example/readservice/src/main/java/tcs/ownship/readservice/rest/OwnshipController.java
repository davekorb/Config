package tcs.ownship.readservice.rest;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tcs.ownship.readservice.dbase.OwnshipRepositoryService;

import java.util.List;

@RequiredArgsConstructor
@RestController
@RequestMapping
public class OwnshipController {
  private final OwnshipRepositoryService ownshipRepoService;

  /**
   * Handles the GET request by returning all of the ownship data in the
   * database
   * @return GetResponse with all of the found ownship data
   */
  @GetMapping("ownship")
  public ResponseEntity<GetResponse>
  getAll() {
    return ResponseEntity.ok(
      GetResponse.builder()
        .data(ownshipRepoService.findAll())
        .build());
  }

  /**
   * Handles the GET request by by time by returning all of the matching ownship data in the
   * database
   * @return GetResponse with all of the found ownship data
   */
  @GetMapping("ownship/byTime")
  public ResponseEntity<GetResponse>
  getTimeRange(@RequestParam("times") List<Long> times) {
    return ResponseEntity.ok(
      GetResponse.builder()
        .data(ownshipRepoService.findTimeRange(times.get(0), times.get(1)))
        .build());
  }
}
