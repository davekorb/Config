package tcs.ownship.readservice.rest;

import lombok.Builder;
import lombok.RequiredArgsConstructor;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Jacksonized
@Builder
@Value
@RequiredArgsConstructor
public class GetRequestByTime
{
  long startTime;
  long endTime;
}
