package tcs.ownship.readservice.dbase;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Objects;

@Entity
@Table(name="Ownship")
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Builder
@Getter
@ToString
public class OwnshipEntity {
  @Id
  private String id;
  private Double latitude;
  private Double longitude;
  private Double mcsX;
  private Double mcsY;
  private Double bearing;
  private Double course;
  private Double speed;
  private Long   time;


  /**
   * Generated code for equality comparison
   * @param o - the object to compare
   * @return true if equal and false if not.
   */
  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    OwnshipEntity that = (OwnshipEntity) o;
    return Objects.equals(id, that.id) && Objects.equals(latitude,
      that.latitude) && Objects.equals(longitude,
      that.longitude) && Objects.equals(mcsX, that.mcsX) && Objects.equals(mcsY,
      that.mcsY) && Objects.equals(bearing, that.bearing) && Objects.equals(
      course, that.course) && Objects.equals(speed, that.speed);
  }
}
