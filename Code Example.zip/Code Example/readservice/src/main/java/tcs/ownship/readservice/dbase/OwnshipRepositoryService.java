package tcs.ownship.readservice.dbase;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import tcs.ownship.readservice.data.Ownship;

import java.util.List;

@Service
@Component
@RequiredArgsConstructor
public class OwnshipRepositoryService {
  private final OwnshipRepository ownshipRepo;

  /**
   * Returns all of the ownship records in the repository.
   * @return A list of ownship records
   */
  public List<Ownship> findAll() {
    return OwnshipEntityMapper.INSTANCE.fromEntities(ownshipRepo.findAll());
  }

  /**
   * Returns all of the ownship records in the repository.
   * @return A list of ownship records
   */
  public List<Ownship> findTimeRange(long startTime, long endTime) {
    return OwnshipEntityMapper.INSTANCE.fromEntities(
      ownshipRepo.findByTimeBetween(startTime, endTime));
  }
}
