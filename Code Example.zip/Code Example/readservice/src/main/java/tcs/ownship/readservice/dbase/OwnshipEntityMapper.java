package tcs.ownship.readservice.dbase;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;
import tcs.ownship.readservice.data.Ownship;

import java.util.List;

@Mapper
public interface OwnshipEntityMapper {
  OwnshipEntityMapper INSTANCE = Mappers.getMapper(OwnshipEntityMapper.class);

  /**
   * Convert to an entity from a POJO
   * @param aOwnship the ownship to convert
   * @return an ownship entity
   */
  OwnshipEntity toEntity(Ownship aOwnship);

  /**
   * Convert from an entity to a POJO
   * @param aEntity the entity to convert
   * @return an ownship POJO
   */
  Ownship fromEntity(OwnshipEntity aEntity);

  /**
   * Convert a list of POJOs to a list of entities
   * @param aOwnship the list of ownships to convert
   * @return the list of converted entities
   */
  List<OwnshipEntity> toEntities(List<Ownship> aOwnship);

  /**
   * Convert from a list of entities to a list of POJOs
   * @param aEntities the list of POJOs to convert
   * @return the list of converted entities
   */
  List<Ownship> fromEntities(List<OwnshipEntity> aEntities);
}
