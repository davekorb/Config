package tcs.ownship.client2;

import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import tcs.ownship.client2.data.Ownship;
import tcs.ownship.client2.interfaces.OwnshipInterface;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.Random;

@Service
@EnableScheduling
@RequiredArgsConstructor
public class ClientService
{
  private final OwnshipInterface ownshipInterface;
  private final Random random = new Random();

  /**
   * Method to get all of the ownship data at the fixedDelay interval.
   */
  @Scheduled(fixedDelay = 2000, initialDelay = 2000)
  private void getAll() {
    List<Ownship> ownshipList = ownshipInterface.getAll();
    System.out.println("<< Getting All records: " + ownshipList.size());
  }

  /**
   * Method to get all of the ownship between the two times generated.
   */
  @Scheduled(fixedDelay = 250, initialDelay = 2000)
  private void getTimeRange() {

    // Make end time the current time and start time somewhere between 10 and 100 seconds earlier
    long endTime = ZonedDateTime.now().toInstant().toEpochMilli();
    long startTime = endTime - (10000 + random.nextInt(90000));

    List<Ownship> ownshipList = ownshipInterface.getTimeRange(startTime, endTime);

    System.out.println("<< Getting records from time " + startTime + " to " + endTime + ": " +
      ownshipList.size());
  }
}
