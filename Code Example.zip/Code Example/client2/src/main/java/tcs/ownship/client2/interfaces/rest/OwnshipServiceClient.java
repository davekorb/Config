package tcs.ownship.client2.interfaces.rest;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@FeignClient(
  name = "ApiGateway")
public interface OwnshipServiceClient
{
  @GetMapping("/ownship")
  GetResponse getAll();

  @GetMapping("/ownship/byTime")
  GetResponse getTimeRange(@RequestParam("times") List<Long> times);
}
