package tcs.ownship.client2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import tcs.ownship.client2.interfaces.OwnshipInterface;
import tcs.ownship.client2.interfaces.rest.OwnshipInterfaceImpl;
import tcs.ownship.client2.interfaces.rest.OwnshipServiceClient;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class Client2Application
{
  public static void main(String[] args) {
    SpringApplication.run(Client2Application.class, args);
  }

  @Bean
  OwnshipInterface createOwnshipInterface(OwnshipServiceClient client) {
    return new OwnshipInterfaceImpl(client);
  }
}
