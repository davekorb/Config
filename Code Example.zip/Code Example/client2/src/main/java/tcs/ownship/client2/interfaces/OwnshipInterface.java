package tcs.ownship.client2.interfaces;

import tcs.ownship.client2.data.Ownship;

import java.util.List;

public interface OwnshipInterface {

  /**
   * Method to get all ownships currently in system
   * @return a list of ownship records.
   */
  List<Ownship> getAll();

  /**
   * Method to get all ownship records current in system between start time and end time.
   * @param startTime the start time of the ownship records to return
   * @param endTime the end time of the ownship records to return
   * @return A list of ownship records between startTime and endTime.
   */
  List<Ownship> getTimeRange(long startTime, long endTime);
}
