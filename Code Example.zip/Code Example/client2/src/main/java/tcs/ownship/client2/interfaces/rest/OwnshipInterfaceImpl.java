package tcs.ownship.client2.interfaces.rest;

import lombok.RequiredArgsConstructor;
import tcs.ownship.client2.data.Ownship;
import tcs.ownship.client2.interfaces.OwnshipInterface;

import java.util.ArrayList;
import java.util.List;

@RequiredArgsConstructor
public class OwnshipInterfaceImpl implements OwnshipInterface {
  private final OwnshipServiceClient ownshipClient;

  /**
   * see OwnshipInterface.getAll
   */
  @Override
  public List<Ownship> getAll() {
    return ownshipClient.getAll().getData();
  }

  /**
   * see OwnshipInterface.getTimeRange
   */
  @Override
  public List<Ownship> getTimeRange(long startTime, long endTime) {
    List<Long> times = new ArrayList<>();
    times.add(startTime);
    times.add(endTime);

    return ownshipClient.getTimeRange(times).getData();
  }
}
