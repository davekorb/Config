package tcs.ownship.client.rest;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import tcs.ownship.client.data.Ownship;

import java.util.ArrayList;
import java.util.List;

@Jacksonized
@Builder
@Value
public class PostRequest
{
  @Builder.Default
  List<Ownship> data = new ArrayList<>();
}
