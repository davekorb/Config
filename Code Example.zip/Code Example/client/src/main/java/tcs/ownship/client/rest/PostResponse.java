package tcs.ownship.client.rest;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Jacksonized
@Builder
@Value
public class PostResponse
{
  @Builder.Default
  Integer  postCount = 0;
}
