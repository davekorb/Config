package tcs.ownship.client.rest;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(
  name = "ApiGateway")
public interface OwnshipServiceClient {
  @PostMapping("/ownship")
  PostResponse post(PostRequest aRequest);
}
