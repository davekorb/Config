package tcs.ownship.client;

import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import tcs.ownship.client.data.Ownship;
import tcs.ownship.client.rest.OwnshipServiceClient;
import tcs.ownship.client.rest.PostRequest;

import java.time.ZonedDateTime;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@EnableScheduling
@RequiredArgsConstructor
public class ClientService
{
  private final OwnshipServiceClient ownshipServiceInterface;
  private int totalCount = 0;

  @Scheduled(fixedDelay = 2000, initialDelay = 2000)
  private void post()
  {
    int maxSend = 2;

    List<Ownship> ownshipList =
      Stream.iterate(0, count -> count + 1)
        .limit(maxSend)
        .map(count ->
          Ownship.builder()
            .id("IDString_" + (totalCount + count))
            .latitude(totalCount + count)
            .longitude(totalCount + count)
            .mcsX(totalCount + count)
            .mcsY(totalCount + count)
            .bearing(totalCount + count)
            .course(totalCount + count)
            .speed(totalCount + count)
            .time(ZonedDateTime.now().toInstant().toEpochMilli())
            .build())
        .collect(Collectors.toList());
    totalCount += maxSend;

    PostRequest request =
      PostRequest.builder()
        .data(ownshipList)
        .build();

    System.out.println("<< Posting " + request);
    ownshipServiceInterface.post(request);
  }
}
