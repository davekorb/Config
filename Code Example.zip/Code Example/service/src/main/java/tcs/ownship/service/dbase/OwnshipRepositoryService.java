package tcs.ownship.service.dbase;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import tcs.ownship.service.data.Ownship;

import java.util.List;

@Service
@Component
@RequiredArgsConstructor
public class OwnshipRepositoryService {
  private final OwnshipRepository ownshipRepo;

  /**
   * Saves the ownship list to the repository
   * @param ownships the ownship records to save
   * @return the ownship records saved.
   */
  public List<Ownship> saveAll(@NonNull List<Ownship> ownships) {
    return OwnshipEntityMapper.INSTANCE.fromEntities(
      ownshipRepo.saveAll(
        OwnshipEntityMapper.INSTANCE.toEntities(ownships)));
  }

  /**
   * Returns all of the ownship records in the repository.
   * @return A list of ownship records
   */
  public List<Ownship> findAll() {
    return OwnshipEntityMapper.INSTANCE.fromEntities(ownshipRepo.findAll());
  }

  /**
   * Returns all of the ownship records in the repository.
   * @return A list of ownship records
   */
  public List<Ownship> findTimeRange(long startTime, long endTime) {
    return OwnshipEntityMapper.INSTANCE.fromEntities(
      ownshipRepo.findByTimeBetween(startTime, endTime));
  }
}
