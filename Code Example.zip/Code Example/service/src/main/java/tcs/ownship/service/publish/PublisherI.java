package tcs.ownship.service.publish;

public interface PublisherI<T> {
  void accept(T data);
}
