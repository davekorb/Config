package tcs.ownship.service.publish;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import tcs.ownship.service.data.Ownship;

import java.util.List;
import java.util.function.Function;

@RequiredArgsConstructor
public class OwnshipPublisher implements PublisherI<List<Ownship>> {
  private final Function<OwnshipEvent, Boolean> sendFunction;

  /**
   * Override the accept method to act as the sender of the data
   * @param ownshipList - the list of ownship records to publish
   */
  public void accept(@NonNull List<Ownship> ownshipList) {
    ownshipList.stream()
      .map(ownship -> OwnshipEvent.builder()
        .type(OwnshipEvent.ChangeType.eAdd)
        .data(ownship)
        .build())
      .forEach(sendFunction::apply);
  }
}
