package tcs.ownship.service.rest;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import tcs.ownship.service.data.Ownship;

import java.util.ArrayList;
import java.util.List;

@Jacksonized
@Builder
@Value
public class PostRequest {
  @Builder.Default
  List<Ownship> data = new ArrayList<>();
}
