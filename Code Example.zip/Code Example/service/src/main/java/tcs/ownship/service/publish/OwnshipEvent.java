package tcs.ownship.service.publish;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;
import tcs.ownship.service.data.Ownship;

@Builder
@Value
@Jacksonized
public class OwnshipEvent
{
  public enum ChangeType {
    eAdd,
    eUpdate,
    eDelete
  }

  ChangeType type;
  Ownship data;
}
