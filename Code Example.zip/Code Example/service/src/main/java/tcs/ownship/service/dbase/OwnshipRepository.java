package tcs.ownship.service.dbase;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface OwnshipRepository extends JpaRepository<OwnshipEntity, String> {

  List<OwnshipEntity> findByTimeBetween(Long startTime, Long endTime);


  // Custom queries possible. Example:
  //
  // @Query("SELECT * FROM TABLE OWNSHIP")
  // List<OwnshipEntities getAllOwnship();
}
