package tcs.ownship.service.rest;

import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import tcs.ownship.service.data.Ownship;
import tcs.ownship.service.dbase.OwnshipRepositoryService;
import tcs.ownship.service.publish.PublisherI;

import java.util.List;


@RequiredArgsConstructor
@RestController
@RequestMapping("ownship")
public class OwnshipController {
  private final OwnshipRepositoryService ownshipRepoService;
  private final PublisherI<List<Ownship>> ownshipPublisher;

  /**
   * Handles the POST request by storing the enclosed list of ownship
   * data to the database
   * @param aRequest: the POST request
   * @return The PostResponse
   */
  @PostMapping
  public ResponseEntity<PostResponse>
  store(@RequestBody PostRequest aRequest) {
    // Save data to the database
    List<Ownship> storedData = ownshipRepoService.saveAll(aRequest.getData());

    // Publish all ownship records stored
    ownshipPublisher.accept(storedData);

    // Return the count of stored ownship records in the response
    return ResponseEntity.ok(
      PostResponse.builder()
        .postCount(storedData.size())
        .build());
  }

  /**
   * Handles the GET request by returning all of the ownship data in the
   * database
   * @return GetResponse with all of the found ownship data
   */
  @GetMapping
  public ResponseEntity<GetResponse>
  getAll() {
    return ResponseEntity.ok(
      GetResponse.builder()
        .data(ownshipRepoService.findAll())
        .build());
  }

  /**
   * Handles the GET request by by time by returning all of the matching ownship data in the
   * database
   * @return GetResponse with all of the found ownship data
   */
  @GetMapping("ownship/byTime")
  public ResponseEntity<GetResponse>
  getTimeRange(@RequestParam("times") List<Long> times) {
    return ResponseEntity.ok(
      GetResponse.builder()
        .data(ownshipRepoService.findTimeRange(times.get(0), times.get(1)))
        .build());
  }
}
