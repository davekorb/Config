package tcs.ownship.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.context.annotation.Bean;
import tcs.ownship.service.data.Ownship;
import tcs.ownship.service.publish.OwnshipEvent;
import tcs.ownship.service.publish.OwnshipPublisher;
import tcs.ownship.service.publish.PublisherI;

import java.util.List;

@SpringBootApplication
@EnableDiscoveryClient
public class ServiceApplication {
  // Get the publish channel from the yaml file.
  @Value("${spring.cloud.stream.bindings.ownshipPublisher-out-0.destination}")
  private String publishChannel;


  // Main
  public static void main(String[] args) {
    SpringApplication.run(ServiceApplication.class, args);
  }

  /**
   * Bean for creating an ownship publisher.
   * @param bridge the stream bridge used to send the data.
   * @return An ownship publisher as a PublishI
   */
  @Bean
  public PublisherI<List<Ownship>> ownshipPublisher(StreamBridge bridge) {
    return new OwnshipPublisher(
      (OwnshipEvent event) -> { return bridge.send(publishChannel, event); });
  }
}
