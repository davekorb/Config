package tcs.ownship.service.IT;

import lombok.RequiredArgsConstructor;
import tcs.ownship.service.data.Ownship;
import tcs.ownship.service.publish.OwnshipEvent;

import java.util.function.Consumer;

@RequiredArgsConstructor
public class PublishReceiver implements Consumer<OwnshipEvent>
{
  private final DataStorage storage;

  @Override
  public void accept(OwnshipEvent ownshipEvent)
  {
    storage.add(ownshipEvent);
  }
}
