package tcs.ownship.service.IT;


import tcs.ownship.service.data.Ownship;
import tcs.ownship.service.publish.OwnshipEvent;

import java.util.ArrayList;
import java.util.List;

public class DataStorage
{
  private final List<Ownship> ownshipList = new ArrayList<>();

  public void add(OwnshipEvent ownshipEvent)
  {
    ownshipList.add(ownshipEvent.getData());
  }
  public void clear()
  {
    ownshipList.clear();;
  }

  public int getCount()
  {
    return ownshipList.size();
  }

  public List<Ownship> getOwnshipList()
  {
    return ownshipList;
  }
}
