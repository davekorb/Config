package tcs.ownship.service.IT;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import tcs.ownship.service.publish.OwnshipEvent;

import java.util.function.Consumer;

@TestConfiguration
public class TestConfig
{
  @Bean
  public Consumer<OwnshipEvent> ownshipConsumer(DataStorage storage)
  {
    return new PublishReceiver(storage);
  }

  @Bean
  public DataStorage dataStorage()
  {
    return new DataStorage();
  }

}
