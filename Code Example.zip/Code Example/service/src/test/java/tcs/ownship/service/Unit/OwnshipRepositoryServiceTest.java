package tcs.ownship.service.Unit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import tcs.ownship.service.data.Ownship;
import tcs.ownship.service.dbase.OwnshipEntity;
import tcs.ownship.service.dbase.OwnshipEntityMapper;
import tcs.ownship.service.dbase.OwnshipRepository;
import tcs.ownship.service.dbase.OwnshipRepositoryService;

import java.util.List;
import java.util.Random;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class OwnshipRepositoryServiceTest
{
  RandomGenerator randomGenerator = new RandomGenerator(new Random());

  @Mock
  OwnshipRepository ownshipRepo;

  @InjectMocks
  OwnshipRepositoryService ownshipRepoService;

  @Captor
  ArgumentCaptor<List<OwnshipEntity>> ownshipEntityCaptor;


  @Test
  @DisplayName("Test saveAll method with 0 entries")
  void TestStoreWithNoEntries()
  {
    verifySaveAll(0);
  }

  @Test
  @DisplayName("Test saveAll method with multiple entries")
  void TestStoreWithMultipleEntries()
  {
    verifySaveAll(randomGenerator.generateInteger(1, 100));
  }

  @Test
  @DisplayName("Test findAll method with 0 entries")
  void TestFindAllWithNoEntries()
  {
    verifyFindAll(0);
  }

  @Test
  @DisplayName("Test findAll method with multiple entries")
  void TestFindAllWithMultipleEntries()
  {
    verifyFindAll(randomGenerator.generateInteger(1, 100));
  }

  /**
  /**
   * Utility function to test multiple return amounts from the findAll
   * @param count - the number of records to test for
   */
  void verifyFindAll(int count)
  {
    List<Ownship> ownshipList = randomGenerator.generateOwnshipList(count);
    List<OwnshipEntity> entities = OwnshipEntityMapper.INSTANCE.toEntities(ownshipList);

    Mockito.when(ownshipRepo.findAll()).thenReturn(entities);

    List<Ownship> returnedOwnshipList = ownshipRepoService.findAll();

    // Verify that the Repository's "findAll" was called correctly.
    verify(ownshipRepo, times(1)).findAll();

    // Verify that the correct number of records was translated and returned
    assertEquals(ownshipList.size(), returnedOwnshipList.size(),
      "Did not get correct number of ownship records");
    assertTrue(ownshipList.containsAll(returnedOwnshipList),
      "Did not get correct ownship records");
  }

  /**
   * Utility function to test multiple length ownship lists passed into the repositories saveAll
   * method
   * @param count - the number of entries to verify
   */
  void verifySaveAll(int count)
  {
    List<Ownship> ownshipList = randomGenerator.generateOwnshipList(count);
    List<OwnshipEntity> ownshipEntities = OwnshipEntityMapper.INSTANCE.toEntities(ownshipList);

    Mockito.when(ownshipRepo.saveAll(ownshipEntities)).thenReturn(ownshipEntities);

    List<Ownship> saveResults = ownshipRepoService.saveAll(ownshipList);


    // Verify that the Repository's "saveAll" was called correctly.
    verify(ownshipRepo, times(1)).saveAll(ownshipEntityCaptor.capture());

    // Verify that the entity capture is correct
    assertEquals(1, ownshipEntityCaptor.getAllValues().size(),
      "Repository SaveAll not called correct number of times");

    List<OwnshipEntity> saveToRepoResults = ownshipEntityCaptor.getAllValues().get(0);
    assertEquals(ownshipEntities.size(), saveToRepoResults.size(),
      "size of ownship entity lists not the same");
    assertTrue(ownshipEntities.containsAll(saveToRepoResults),
      "Saved Ownship entity lists are not the same");

    // verify that the returned ownship records are correct.
    assertEquals(ownshipList.size(), saveResults.size(),
      "size of saved ownship arrays not the same");
    assertTrue(ownshipList.containsAll(saveResults),
      "Saved Ownship records are not the same");
  }
}
