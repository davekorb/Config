package tcs.ownship.service.IT;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.containers.RabbitMQContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import tcs.ownship.service.ServiceApplication;
import tcs.ownship.service.Unit.RandomGenerator;
import tcs.ownship.service.data.Ownship;
import tcs.ownship.service.dbase.OwnshipEntity;
import tcs.ownship.service.dbase.OwnshipEntityMapper;
import tcs.ownship.service.dbase.OwnshipRepository;
import tcs.ownship.service.publish.OwnshipEvent;
import tcs.ownship.service.rest.GetResponse;
import tcs.ownship.service.rest.PostRequest;
import tcs.ownship.service.rest.PostResponse;

import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import static org.awaitility.Awaitility.await;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest(
  classes = ServiceApplication.class,
  webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Testcontainers
@Import(TestConfig.class)
class ServiceApplicationTests
{
  @Container
  static final RabbitMQContainer rabbitMQContainer = new RabbitMQContainer(
    DockerImageName.parse("rabbitmq").withTag("3.7.25-management-alpine"));

  @Container
  static final MariaDBContainer<?> mariaDBContainer = new MariaDBContainer<>(
    DockerImageName.parse("mariadb:10.5.5"));

  @LocalServerPort
  private int port;

  @Autowired
  private OwnshipRepository ownshipRepo;

  private final TestRestTemplate interfaceToOwnshipService = new TestRestTemplate();

  private final RandomGenerator randomGenerator = new RandomGenerator(new Random());

  @Autowired
  Consumer<OwnshipEvent> receiver;

  @Autowired
  DataStorage storage;


  @DynamicPropertySource
  static void configure(DynamicPropertyRegistry registry)
  {
    registry.add("spring.rabbitmq.host", rabbitMQContainer::getContainerIpAddress);
    registry.add("spring.rabbitmq.port", rabbitMQContainer::getAmqpPort);
    registry.add("spring.datasource.url", mariaDBContainer::getJdbcUrl);
    registry.add("spring.datasource.username", mariaDBContainer::getUsername);
    registry.add("spring.datasource.password", mariaDBContainer::getPassword);
  }

  @AfterAll
  public static void shutdown()
  {
    mariaDBContainer.stop();
    rabbitMQContainer.stop();
  }

  @BeforeAll
  public static void initialize()
  {
  }

  @AfterEach
  public void cleanup()
  {
    ownshipRepo.deleteAll();
    storage.clear();
  }

  @Test
  void contextLoads()
  {
    mariaDBContainer.isRunning();
    rabbitMQContainer.isRunning();
  }


  @Test
  @DisplayName("Tests GET of all ownship records from the service when zero are stored")
  void TestGetAllOwnshipWithZeroRecords()
  {
    postAndGetAllOwnshipRecords(0);
  }

  @Test
  @DisplayName("Tests GET of all ownship records from the service when random number are stored")
  void TestGetAllOwnshipWithRandomRecordCount()
  {
    postAndGetAllOwnshipRecords(randomGenerator.generateInteger(1,20));
  }

  @Test
  @DisplayName("Tests posting zero ownship records to the service database")
  void TestPostOwnshipOfZeroRecords()
  {
    List<Ownship> ownshipList = postAndReturnOwnshipRecords(0);
    await()
      .during(5, TimeUnit.SECONDS)
      .atMost(6, TimeUnit.SECONDS)
      .until(() -> storage.getCount() == 0);
  }

  @Test
  @DisplayName("Tests posting random number of ownship records to the service and " +
    "eventually the database")
  void TestPostOwnshipOfRandomRecordCount()
  {
    List<Ownship> ownshipList = postAndReturnOwnshipRecords(randomGenerator.generateInteger(5,20));
    await()
      .atMost(5, TimeUnit.SECONDS)
      .until(() -> storage.getCount() == ownshipList.size());

    assertEquals(ownshipList.size(), storage.getOwnshipList().size(),
      "Number of ownship records received are not the same as ones sent");

    assertTrue(ownshipList.containsAll(storage.getOwnshipList()),
      "Ownship Records not the same");
  }

  /**
   * Utility function to POST and GET the ownship records that have been stored.
   * @param count - the number of ownship records to post and get.
   */
  void postAndGetAllOwnshipRecords(int count)
  {
    List<Ownship> ownshipList = postAndReturnOwnshipRecords(count);

    HttpEntity<PostRequest> request =
      new HttpEntity<>(
        new HttpHeaders());

    ResponseEntity<GetResponse> response =
      interfaceToOwnshipService.exchange(
        "http://localhost:" + port + "/ownship",
        HttpMethod.GET,
        request,
        GetResponse.class);

    assertEquals(HttpStatus.OK, response.getStatusCode(), "GET Response NOT OK");
    assertEquals(ownshipList.size(), Objects.requireNonNull(response.getBody()).getData().size(),
      "Incorrect number of records returned from GET");
    assertTrue(ownshipList.containsAll(Objects.requireNonNull(response.getBody()).getData()),
      "Incorrect records returned from GET");
  }

  /**
   * Utility function to post ownshipList to the service and return the ownshipList
   * @param count - the number of ownship records to post.
   * @return The list of ownship records posted
   */
  List<Ownship> postAndReturnOwnshipRecords(int count)
  {
    List<Ownship> ownshipList = randomGenerator.generateOwnshipList(count);
    List<OwnshipEntity> ownshipEntities = OwnshipEntityMapper.INSTANCE.toEntities(ownshipList);

    HttpEntity<PostRequest> request =
      new HttpEntity<>(
        PostRequest.builder()
          .data(ownshipList)
          .build(),
        new HttpHeaders());

    ResponseEntity<PostResponse> response =
      interfaceToOwnshipService.exchange(
        "http://localhost:" + port + "/ownship",
        HttpMethod.POST,
        request,
        PostResponse.class);

    assertEquals(HttpStatus.OK, response.getStatusCode(), "POST Response NOT OK");
    assertEquals(ownshipList.size(), Objects.requireNonNull(response.getBody()).getPostCount(),
      "Incorrect number of records reported stored");

    List<Ownship> ownshipResults =
      OwnshipEntityMapper.INSTANCE.fromEntities(ownshipRepo.findAll());
    assertEquals(ownshipList.size(), ownshipResults.size(),
      "Repository did not store correct number of ownship records");
    assertTrue(ownshipList.containsAll(ownshipResults),
      "Repository did not store correct ownship records");

    List<OwnshipEntity> ownshipRepoResults = ownshipRepo.findAll();
    assertNotNull(ownshipRepoResults, "Ownship Repo returned null results");
    assertEquals(ownshipEntities.size(), ownshipRepoResults.size(),
      "Ownship Repo does not contain correct number of entries");
    assertTrue(ownshipEntities.containsAll(ownshipRepoResults),
      "Ownship Repo does not contain correct entries");

    return ownshipList;
  }
}
