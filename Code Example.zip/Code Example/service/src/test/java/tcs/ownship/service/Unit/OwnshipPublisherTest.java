package tcs.ownship.service.Unit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import tcs.ownship.service.data.Ownship;
import tcs.ownship.service.publish.OwnshipEvent;
import tcs.ownship.service.publish.OwnshipPublisher;

import java.util.List;
import java.util.Random;
import java.util.function.Function;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
public class OwnshipPublisherTest
{
  RandomGenerator randomGenerator = new RandomGenerator(new Random());

  @Mock
  Function<OwnshipEvent, Boolean> sendFunction;

  @Captor
  ArgumentCaptor<OwnshipEvent> ownshipEventCaptor;


  @Test
  @DisplayName("Test Accept method with 0 entries")
  void TestAcceptWithNoEntries()
  {
    verifyAcceptFunction(0);
  }

  @Test
  @DisplayName("Test Accept method with 1 entries")
  void TestAcceptWithOneEntries()
  {
    verifyAcceptFunction(1);
  }

  @Test
  @DisplayName("Test Accept method with multiple entries")
  void TestAcceptWithMultipleEntries()
  {
    verifyAcceptFunction(10);
  }

  /**
   * Utility function to test multiple length ownship lists passed into the publishers accept
   * method
   * @param count - the number of records to verify
   */
  void verifyAcceptFunction(int count)
  {
    List<Ownship> ownshipList = randomGenerator.generateOwnshipList(count);
    List<OwnshipEvent> ownshipEvents =
      ownshipList.stream()
        .map(os -> OwnshipEvent.builder()
          .type(OwnshipEvent.ChangeType.eAdd)
          .data(os)
          .build())
        .collect(Collectors.toList());

    OwnshipPublisher publisher = new OwnshipPublisher(sendFunction);
    publisher.accept(ownshipList);

    // Verify that the "send" was called "count" times
    verify(sendFunction, times(count)).apply(ownshipEventCaptor.capture());

    assertEquals(count, ownshipEventCaptor.getAllValues().size(),
      "Send not called correct number of times");
    assertEquals(ownshipEvents, ownshipEventCaptor.getAllValues(),
      "Ownship events are not the same");
  }
}
