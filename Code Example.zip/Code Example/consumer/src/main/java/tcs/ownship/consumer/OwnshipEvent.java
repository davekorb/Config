package tcs.ownship.consumer;

import lombok.Builder;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

@Builder
@Value
@Jacksonized
public class OwnshipEvent {
  public enum ChangeType {
    eAdd,
    eUpdate,
    eDelete
  }

  ChangeType type;
  Ownship data;
}
