package tcs.ownship.consumer;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Builder.Default;
import lombok.NoArgsConstructor;
import lombok.Value;
import lombok.extern.jackson.Jacksonized;

import java.time.ZonedDateTime;
import java.util.UUID;

@AllArgsConstructor(access = AccessLevel.PRIVATE)
@NoArgsConstructor
@Builder
@Value
@Jacksonized
public class Ownship
{
  @Default
  String id = UUID.randomUUID().toString();

  @Default
  double latitude = 0;

  @Default
  double longitude = 0.;

  @Default
  double mcsX = 0.;

  @Default
  double mcsY = 0.;

  @Default
  double bearing = 0.;

  @Default
  double course = 0.;

  @Default
  double speed = 0.;

  @Default
  long time = 0;
}
